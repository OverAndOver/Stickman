package stickman.model;
import stickman.levels.*;
import org.json.simple.JSONObject;

public class GameEngineImpl implements GameEngine {
    Level currentLevel;
    int currentLevelNumber;
    LevelDirector levelDirector;
    JSONObject configuration;



    public GameEngineImpl(JSONObject configuration) {
        this.configuration = configuration;
        this.currentLevelNumber = 1;
        startLevel();
    }

    private void loadLevel(int levelNumber) {
        JSONObject levels = (JSONObject)configuration.get("levels");

        String key = String.valueOf(levelNumber);
        JSONObject level = (JSONObject)levels.get(key);

        if (level != null) {
            levelDirector = new LevelDirector(new DefaultLevelBuilder(level));
            currentLevel = levelDirector.construct();
        }
    }

    @Override
    public Level getCurrentLevel() {
        return currentLevel;
    }

    @Override
    public void startLevel() {
        loadLevel(this.currentLevelNumber);
    }

    @Override
    public boolean jump() {
        return currentLevel.jump();
    }

    @Override
    public boolean moveLeft() {
        currentLevel.moveLeft();
        return false;
    }

    @Override
    public boolean moveRight() {
        currentLevel.moveRight();
        return false;
    }

    @Override
    public boolean stopMoving() {
        currentLevel.stopMoving();
        return false;
    }

    @Override
    public void tick() {
        if (currentLevel.levelLost())
            startLevel();
        currentLevel.tick();

    }
}
